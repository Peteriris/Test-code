--
-- PostgreSQL database dump
--

-- Dumped from database version 12.9
-- Dumped by pg_dump version 12.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: userlogin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.userlogin (
    usid integer NOT NULL,
    username character varying,
    email character varying,
    passwords character varying
);


ALTER TABLE public.userlogin OWNER TO postgres;

--
-- Name: userlogin_usid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.userlogin_usid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.userlogin_usid_seq OWNER TO postgres;

--
-- Name: userlogin_usid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.userlogin_usid_seq OWNED BY public.userlogin.usid;


--
-- Name: userlogin usid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userlogin ALTER COLUMN usid SET DEFAULT nextval('public.userlogin_usid_seq'::regclass);


--
-- Data for Name: userlogin; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.userlogin VALUES (1, 'Antony Babu', 'antonybabuarimbo@gmail.com', '123456');
INSERT INTO public.userlogin VALUES (2, 'Iris MAthew', 'irismathew20@gmail.com', '654321');
INSERT INTO public.userlogin VALUES (3, 'man', 'abc@gmail.com', '987654');
INSERT INTO public.userlogin VALUES (4, 'man', 'abcd@gmail.com', '123456');


--
-- Name: userlogin_usid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.userlogin_usid_seq', 4, true);


--
-- Name: userlogin userlogin_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userlogin
    ADD CONSTRAINT userlogin_email_key UNIQUE (email);


--
-- Name: userlogin userlogin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userlogin
    ADD CONSTRAINT userlogin_pkey PRIMARY KEY (usid);


--
-- PostgreSQL database dump complete
--

